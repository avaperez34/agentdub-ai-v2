# AgentDub.ai — Manus-style export (static)

## Deploy
Upload all files to a new GitHub repo and enable GitHub Pages (main branch / root).

## IMPORTANT: Gumroad link
Open `navigator.html` and replace:
`https://YOUR-GUMROAD-PRODUCT-URL`
with your real Gumroad product link.

## Paywall note
This is a static-site paywall (preview gating):
- Shows only 3 companies
- "Unlock / See more" redirects to Gumroad
- Paid downloadable list should be delivered by Gumroad
