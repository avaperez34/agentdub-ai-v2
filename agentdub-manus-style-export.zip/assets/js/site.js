(function () {
  const btn = document.querySelector('[data-nav-toggle]');
  const links = document.querySelector('[data-nav-links]');
  if (btn && links) btn.addEventListener('click', () => links.classList.toggle('open'));

  const url = encodeURIComponent(window.location.href);
  const title = encodeURIComponent(document.title);

  const li = document.querySelector('[data-share-linkedin]');
  const x = document.querySelector('[data-share-x]');
  const fb = document.querySelector('[data-share-facebook]');
  if (li) li.href = `https://www.linkedin.com/sharing/share-offsite/?url=${url}`;
  if (x)  x.href  = `https://twitter.com/intent/tweet?text=${title}&url=${url}`;
  if (fb) fb.href = `https://www.facebook.com/sharer/sharer.php?u=${url}`;

  // Navigator preview gating (static)
  const listEl = document.querySelector('[data-navigator-list]');
  const showMoreBtn = document.querySelector('[data-show-more]');
  const gumroadBtn = document.querySelector('[data-gumroad-buy]');

  if (listEl) {
    const full = JSON.parse(listEl.getAttribute('data-full') || '[]');
    const previewCount = Number(listEl.getAttribute('data-preview-count') || 3);
    const params = new URLSearchParams(window.location.search);
    const unlocked = params.get('unlocked') === '1'; // manual unlock for testing only
    const items = unlocked ? full : full.slice(0, previewCount);

    listEl.innerHTML = items.map((c) => {
      const tags = (c.tags || []).map(t => `<span class="tag">${t}</span>`).join('');
      return `
        <div class="row">
          <div style="flex:1">
            <strong>${c.name}</strong>
            <div class="muted">${c.one_liner}</div>
            <div class="tags">${tags}</div>
          </div>
          <div class="pill">${c.location || 'GCC'}</div>
        </div>
      `;
    }).join('');

    if (!unlocked && showMoreBtn) showMoreBtn.style.display = 'inline-flex';
    if (unlocked && showMoreBtn) showMoreBtn.style.display = 'none';
  }

  if (showMoreBtn) {
    showMoreBtn.addEventListener('click', () => {
      const dest = gumroadBtn?.getAttribute('href') || '#';
      window.location.href = dest;
    });
  }
})();